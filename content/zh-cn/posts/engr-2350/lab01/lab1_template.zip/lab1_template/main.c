//////////////////////////
// Lab 1
// ENGR-2350 S25
// Names: XXXX
// Section: X
// Side: X
// Seat: X
//////////////////////////

#include "engr2350_msp432.h"
#include "lab1lib.h"

void GPIOInit();
void testIO();
void controlSystem();

uint8_t LEDFL = 0; // Two variables to store the state of
uint8_t LEDFR = 0; // the front left/right LEDs (on-car)

int main() {    //// Main Function ////

    sysInit(); // Basic car initialization
    initSequence(); // Initializes the lab1Lib Driver
    GPIOInit();

    printf("\r\n\n"
           "===========\r\n"
           "Lab 1 Begin\r\n"
           "===========\r\n");

    while(1){
        testIO(); // Used in Part A to test the IO
        //controlSystem(); // Used in Part B to implement the desired functionality
    }
}    //// Main Function ////


void GPIOInit(){
    // Add initializations of inputs and outputs
}

void testIO(){
    // Add printf statement(s) for testing inputs

    // Example code for testing outputs
    while(1){
        uint8_t cmd = getchar();
        if(cmd == 'a'){
            // Turn LEDL On
        }else if(cmd == 'z'){
            // Turn LEDL Off
        }// ...
    }
}

void controlSystem(){

}
